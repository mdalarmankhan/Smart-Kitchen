<?php

$name= $_REQUEST['name'];
$email= $_REQUEST['email'];
$contact= $_REQUEST['phone'];
$add= $_REQUEST['address'];


if(!empty($_POST['check_list'])){

foreach($_POST['check_list'] as $selected){
echo $selected."</br>";
}
$services_needed =$_REQUEST['check_list[]'];
$allcheckboxes=implode(", ", $services_needed);


$to="info@kreativejohnys.com";

$message=' Email Id: '.$email  ."\n". ' From: '.$name  ."\n". ' Contact: '.$contact  ."\n".' Message: '.$add  ."\n".' Services applied for: '.$allcheckboxes  ."\n".
$headers = "From: info@kreativejohnys.com";


//mail($to, $message, "From : " . $name);
//echo "Your message has been sent!";

//echo("$name $email  $message $to $headers");

$val=mail($to,"Services for Smart Kitchen",$message,$headers);


if ($val) { ?>
        <script language="javascript" type="text/javascript">
            alert('Thanks! Your email has been sent.');
            window.location = 'index.html';
        </script>
    <?php
    }
    else { ?>
        <script language="javascript" type="text/javascript">
            alert('Sorry, something went wrong.');
            window.location = 'index.html';
        </script>
 <?php
    }
Header("refresh:2;url=index.html");
?>


